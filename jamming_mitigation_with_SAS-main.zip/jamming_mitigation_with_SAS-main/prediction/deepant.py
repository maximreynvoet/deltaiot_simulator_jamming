import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import RMSprop, Adam
from tensorflow.keras.layers import Dense, Dropout, GRU, LSTM, Bidirectional, Input
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.regularizers import l1, l2
from tensorflow.keras.activations import relu

def build_convolutional_auto_encoder(seq_len, feature_dim = 1):
    model = keras.Sequential(
    [
        layers.Input(shape=(seq_len, feature_dim)),
        layers.Conv1D(
            filters=20, kernel_size=8, padding="same", strides=2, activation="relu", kernel_initializer="uniform"
        ),
        # layers.Dropout(rate=0.1),
        layers.MaxPool1D(20, padding="same", strides = 1),
        layers.Conv1D(
            filters=12, kernel_size=6, padding="same", strides=2, activation="relu", kernel_initializer="uniform"
        ),
        layers.MaxPool1D(8, padding="same", strides = 1),
        layers.Flatten(),
        layers.Dense(100, activation = relu, kernel_initializer="uniform"),
        layers.Dense(50, activation = relu, kernel_initializer="uniform"),
        layers.Dense(25, activation = relu, kernel_initializer="uniform"),
        layers.Dense(10, activation = relu, kernel_initializer="uniform"),
        layers.Dense(1, activation = relu, kernel_initializer="uniform"),
    ]
    )
    model.compile(optimizer=keras.optimizers.Nadam(learning_rate=1e-3), loss="mae")
    return model
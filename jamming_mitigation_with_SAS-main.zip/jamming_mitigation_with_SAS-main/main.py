from common.dataset_helper import *
from tqdm import tqdm
import plotly.graph_objects as go
from prediction.deepant import *
import scipy.stats as stats
from statsmodels.tsa.arima.model import ARIMA
from typing import Optional, List
from fastapi import FastAPI, Body
from pydantic import BaseModel
from common.dataset_helper import *
from prediction.deepant import *

app = FastAPI()

tf.random.set_seed(100343)

# read data from stream
# stream_len = 4000
# pls = []
# # with open("./data/standard_packetloss.csv", "r") as plf:
# with open("./data/dataset_with_all_features_00098_1000_1500_-35.0.csv", "r") as plf:    
#     for i in tqdm(range(1, stream_len)):
#         # reading actual values
#         pls.append(float(plf.readline()[0:-1])) # this 0 index can be any other index

# minimum_offset_for_normalizing = 30

################################### ARIMA #######################################

#training
app.minimum_offset_for_normalizing = 30
app.arima_models = {}
app.packetlosses = {}
app.arima_prediction_errors = {}
app.arima_predicted_pl = {}
app.arima_counter = 1


app.window_size = 100
app.deepant_models = {}
app.deepant_prediction_errors = {}
app.deepant_predicted_pl = {}
app.deepant_counter = 1

app.packetloss_epsilon = 0.0

@app.post("/learning/ARIMA/initiate")
def initilizing_arima(packetloss_series: dict = Body(...)):
    
    try:
        app.arima_prediction_errors = {}
        app.arima_predicted_pl = {}
        app.arima_models = {}
        app.packetlosses = packetloss_series
        app.arima_counter = 1
        for link_id, pls_list in packetloss_series.items():
            app.arima_prediction_errors[link_id] = []
            app.arima_predicted_pl[link_id] = []
            app.arima_models[link_id] = ARIMA([x + app.packetloss_epsilon for x in pls_list], order=(1,1,2))
            app.arima_models[link_id] = app.arima_models[link_id].fit()
        return {"status": 1}
    except Exception as e:
        print(e)
        return {"status": 0} 

@app.post("/learning/ARIMA/detect")
def is_anomaly_arima(packetloss: dict = Body(...)):
    detected_anomalies = []
    for i, x in packetloss.items():
        next_predict = app.arima_models[i].predict(app.arima_counter)
        print(app.arima_counter)
        print(next_predict[-1])
        app.arima_predicted_pl[i].append(next_predict[-1])
        app.arima_prediction_errors[i].append((x + app.packetloss_epsilon) - next_predict[-1])
        if(len(app.arima_prediction_errors[i]) > app.minimum_offset_for_normalizing):    
            zscores = stats.zscore(app.arima_prediction_errors[i])
            if(zscores[-1] > 3): # 3*sigma range method
                # print("Potential jamming attack")
                detected_anomalies.append(1)
                del app.arima_prediction_errors[i][-1]
            elif(zscores[-1] < -3): 
                # print("Potential change in environment")
                del app.arima_prediction_errors[i][-1]
                detected_anomalies.append(0)
            else:
                detected_anomalies.append(0)
        else:
            detected_anomalies.append(0)
        app.packetlosses[i].append(x)
    app.arima_counter += 1
    return {"anomaly_state": detected_anomalies}


@app.post("/learning/DeepAnt/initiate")
def initilizing_deepant(packetloss_series: dict = Body(...)):
    try:
        app.deepant_prediction_errors = {}
        app.deepant_predicted_pl = {}
        app.deepant_models = {}
        app.packetlosses = packetloss_series
        app.deepant_counter = 1
        for link_id, pls_list in tqdm(packetloss_series.items()):
            app.deepant_prediction_errors[link_id] = []
            app.deepant_predicted_pl[link_id] = []
            X , y = create_data_set([x + app.packetloss_epsilon for x in pls_list], window_len=app.window_size)
            app.deepant_models[link_id] = build_convolutional_auto_encoder(app.window_size)
            app.deepant_models[link_id].fit(np.array(X),np.array(y),epochs=100, batch_size=32,validation_split=0.2,
                                            callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=30, mode="min")])
        return {"status": 1}
    except Exception as e:
        print(e)
        return {"status": 0} 
    
@app.post("/learning/DeepAnt/detect")
def is_anomaly_deepant(packetloss: dict = Body(...)):
    detected_anomalies = []
    for i, x in packetloss.items():
        next_input = [[i] for i in app.packetlosses[i][-app.window_size:]]
        next_predict = app.deepant_models[i].predict(np.array([next_input]))
        app.deepant_predicted_pl[i].append(next_predict[0][0])
        app.deepant_prediction_errors[i].append((x + app.packetloss_epsilon) - next_predict[0][0])
        if(len(app.deepant_prediction_errors[i]) > app.minimum_offset_for_normalizing):    
            zscores = stats.zscore(app.deepant_prediction_errors[i])
            if(zscores[-1] > 3): # 3*sigma range method
                # print("Potential jamming attack")
                detected_anomalies.append(1)
                del app.deepant_prediction_errors[i][-1]
            elif(zscores[-1] < -3): 
                # print("Potential change in environment")
                del app.deepant_prediction_errors[i][-1]
                detected_anomalies.append(0)
            else:
                detected_anomalies.append(0)
        else:
            detected_anomalies.append(0)
        app.packetlosses[i].append(x)
    app.deepant_counter += 1
    return {"anomaly_state": detected_anomalies}
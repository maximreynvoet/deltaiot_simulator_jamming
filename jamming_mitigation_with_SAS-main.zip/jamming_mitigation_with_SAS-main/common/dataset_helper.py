def create_data_set(time_series, window_len = 30, output_len = 1):
    X = []
    y = []
    for i in range(len(time_series) - window_len):
        X.append([[x] for x in time_series[i:(i+window_len)]])
        if(output_len == 1):
            y.append([time_series[i + window_len]])
        elif(output_len > 1):
            y.append([[x] for x in time_series[(i + window_len):(i + window_len+output_len)]])
        else:
            raise Exception(f"Requested output length {output_len} is not valid.")
    return X,y
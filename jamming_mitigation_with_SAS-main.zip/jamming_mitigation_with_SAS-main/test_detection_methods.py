from common.dataset_helper import *
from tqdm import tqdm
import plotly.graph_objects as go
from prediction.deepant import *
import scipy.stats as stats
from statsmodels.tsa.arima.model import ARIMA

tf.random.set_seed(100343)

# read data from stream
stream_len = 4000
pls = []
# with open("./data/standard_packetloss.csv", "r") as plf:
with open("./data/dataset_with_all_features_00098_1000_1500_-35.0.csv", "r") as plf:    
    for i in tqdm(range(1, stream_len)):
        # reading actual values
        pls.append(float(plf.readline()[0:-1])) # this 0 index can be any other index

minimum_offset_for_normalizing = 30

################################### ARIMA #######################################

#training
end_of_training_cycle_for_ARIMA = 500
arima_model = ARIMA(pls[:end_of_training_cycle_for_ARIMA], order=(1,1,2))  
arima_model = arima_model.fit()

# predicting packet-loss over time and detection
predicted_pl_ARIMA = pls[:end_of_training_cycle_for_ARIMA]
counter = 1
prediction_errors = []
detected_attack_idxs_ARIMA = []
for x in tqdm(range(end_of_training_cycle_for_ARIMA, stream_len-1)):
    # next_input = [[i] for i in pls[(x-window_size):x]]
    next_predict = arima_model.forecast(counter)
    predicted_pl_ARIMA.append(next_predict[0][-1])
    prediction_errors.append(pls[x] - next_predict[0][-1])
    # detection method using zscore: 3*sigma method
    if(len(prediction_errors) > minimum_offset_for_normalizing):    
        zscores = stats.zscore(prediction_errors)
        if(zscores[-1] > 3): # 3*sigma range method
            # print("Potential jamming attack")
            detected_attack_idxs_ARIMA.append(x)
            del prediction_errors[-1]
        elif(zscores[-1] < -3): 
            # print("Potential change in environment")
            del prediction_errors[-1]
    counter += 1
    # arima_model = ARIMA(pls[(x-end_of_training_cycle_for_ARIMA):x], order=(1,1,2))  
    # arima_model = arima_model.fit()

####################################### DeepAnT ##################################

#training
window_size = 100
end_of_training_cycle_for_CNN = 500
conv_predictor = build_convolutional_auto_encoder(window_size)
print(conv_predictor.summary())
X , y = create_data_set(pls[:end_of_training_cycle_for_CNN], window_len=window_size)

conv_predictor.fit(np.array(X),np.array(y),epochs=100, batch_size=32,validation_split=0.2,
            # callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=10, mode="min")]
    )

# predicting packet-loss over time and detection
predicted_pl_CNN = pls[:end_of_training_cycle_for_CNN]
prediction_errors = []
detected_attack_idxs_CNN = []
for x in tqdm(range(end_of_training_cycle_for_CNN, stream_len-1)):
    next_input = [[i] for i in pls[(x-window_size):x]]
    next_predict = conv_predictor.predict(np.array([next_input]))
    predicted_pl_CNN.append(next_predict[0][0])
    prediction_errors.append(pls[x] - next_predict[0][0])
    # detection method using zscore: 3*sigma method
    if(len(prediction_errors) > minimum_offset_for_normalizing):    
        zscores = stats.zscore(prediction_errors)
        if(zscores[-1] > 3): # 3*sigma range method
            # print("Potential jamming attack")
            detected_attack_idxs_CNN.append(x)
            del prediction_errors[-1]
        elif(zscores[-1] < -3):
            # print("Potential change in environment")
            del prediction_errors[-1]
    #     else:
    #         conv_predictor.fit(np.array(next_input), np.array([[pls[x]]])
    # else:
    #     conv_predictor.fit(np.array(next_input), np.array([[pls[x]]])



####################################### Visualization ##################################
same_detected_point = np.intersect1d(detected_attack_idxs_ARIMA, detected_attack_idxs_CNN)
specific_detection_ARIMA = np.setdiff1d(detected_attack_idxs_ARIMA, detected_attack_idxs_CNN)
specific_detection_CNN = np.setdiff1d(detected_attack_idxs_CNN, detected_attack_idxs_ARIMA)
# plot (predicted) packetloss over time (adaptation cycles)
fig = go.Figure(data=[go.Scatter(y = pls, name = "packet loss"), 
                      go.Scatter(y = predicted_pl_CNN, name = "predicted packet loss (DeepAnT)"),
                      go.Scatter(y = predicted_pl_ARIMA, name = "predicted packet loss (ARIMA)"),
                      go.Scatter(x = same_detected_point, y = [pls[i] for i in same_detected_point], marker_symbol = ["x"] * len(same_detected_point),
                                 mode="markers", marker=dict(color='green'), name = "detected potential jamming attacks (by both)",
                                 marker_size = 10),
                      go.Scatter(x = specific_detection_CNN, y = [pls[i] for i in specific_detection_CNN],marker_symbol = ["star"]*len(specific_detection_CNN),
                                 mode="markers", marker=dict(color='red'), name = "detected potential jamming attacks (DeepAnT)",
                                 marker_size = 10),
                      go.Scatter(x = specific_detection_ARIMA, y = [pls[i] for i in specific_detection_ARIMA], marker_symbol = ["square"]*len(specific_detection_ARIMA),
                                 mode="markers", marker=dict(color='black'), name = "detected potential jamming attacks (ARIMA)",
                                 marker_size = 10)])
fig.show()
#/usr/bin/bash
# standard = initialize
java -jar deltaiot_simulator.jar 11125 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11125.txt
# Hybrid jammer  - deepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 11120 -randomjam 30 120 -50 300 265 70 20 false false DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11120_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 11121 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11121.txt
# Cut jammer - deepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 11122 -randomjam 30 120 -50 250 350 70 20 false false DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11122_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 11123 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11123.txt
# Leaf jammer  - deepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 11124 -randomjam 30 120 -50 630 420 70 20 false false DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11124_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt

#mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 11132 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11132.txt
# Hybrid jammer  - deepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 11133 -randomjam 30 120 -50 300 265 70 20 true true DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11133_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 11134 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11134.txt
# Cut jammer - deepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 11135 -randomjam 30 120 -50 250 350 70 20 true true DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11135_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 11136 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_11136.txt
# Leaf jammer  - deepAnT - RSSI true and Mitigation true
ava -jar deltaiot_simulator.jar 11137 -randomjam 30 120 -50 630 420 70 20 true true DeepAnT > ./../output/deltaiotv1/details/randomjam/details_jam_run11137_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt


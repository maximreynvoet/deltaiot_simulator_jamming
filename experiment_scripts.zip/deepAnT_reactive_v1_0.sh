#/usr/bin/bash
# standard = initialize
java -jar deltaiot_simulator.jar 0125 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_0125.txt
# Hybrid jammer  - deepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 6120 -reactivejam 30 120 -50 300 265   false false DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run6120_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 6121 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_0121.txt
# Cut jammer - deepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 6122 -reactivejam 30 120 -50 250 350   false false DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run6122_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 0123 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_0123.txt
# Leaf jammer  - deepAnT - RSSI false and Mitigation false
jjava -jar deltaiot_simulator.jar 6124 -reactivejam 30 120 -50 630 420   false false DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run0624_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt


# mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 7132 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_7132.txt
# Hybrid jammer  - deepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 7133 -reactivejam 30 120 -50 300 265   true true DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run7133_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 7134 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_7134.txt
# Cut jammer - deepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 7135 -reactivejam 30 120 -50 250 350   true true DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run7135_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 7136 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_7136.txt
# Leaf jammer  - deepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 7137 -reactivejam 30 120 -50 630 420   true true DeepAnT > ./../output/deltaiotv1/details/reactivejam/details_jam_run7137_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt

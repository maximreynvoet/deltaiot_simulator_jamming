#/usr/bin/bash
# standard = initialize
java -jar deltaiot_simulator.jar 38125 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_38125.txt
# Hybrid jammer  - DeepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 38120 -constantjam 30 120 -50 300 265   false false DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run38120_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 38121 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_38121.txt
# Cut jammer - DeepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 38122 -constantjam 30 120 -50 250 350   false false DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run38122_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 38123 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_38123.txt
# Leaf jammer  - DeepAnT - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 55126 -constantjam 30 120 -50 630 420   false false DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run55126_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_DeepAnT.txt

#

# mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 39132 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_39132.txt
# Hybrid jammer  - DeepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 39133 -constantjam 30 120 -50 300 265   true true DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run39133_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 39134 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_39134.txt
# Cut jammer - DeepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 39135 -constantjam 30 120 -50 250 350   true true DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run39135_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt
# standard = initialize
java -jar deltaiot_simulator.jar 39136 standard DeepAnT > ./../output/deltaiotv1/details/standard/standard_39136.txt
# Leaf jammer  - DeepAnT - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 55130 -constantjam 30 120 -50 630 420   true true DeepAnT > ./../output/deltaiotv1/details/constantjam/details_jam_run55130_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_DeepAnT.txt



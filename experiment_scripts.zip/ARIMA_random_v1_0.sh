#/usr/bin/bash
# standard = initialize
java -jar deltaiot_simulator.jar 55325 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5525.txt
# Hybrid jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 5520 -randomjam 30 120 -50 300 265 70 20 false false ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5520_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 5521 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5521.txt
# Cut jammer - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 5522 -randomjam 30 120 -50 250 350 70 20 false false ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5522_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 5523 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5523.txt
# Leaf jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 5524 -randomjam 30 120 -50 630 420 70 20 false false ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5524_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt

#mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 5532 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5532.txt
# Hybrid jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 5533 -randomjam 30 120 -50 300 265 70 20 true true ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5533_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 5534 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5534.txt
# Cut jammer - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 5535 -randomjam 30 120 -50 250 350 70 20 true true ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5535_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 5536 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5536.txt
# Leaf jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 5537 -randomjam 30 120 -50 630 420 70 20 true true ARIMA > ./../output/deltaiotv1/details/randomjam/details_jam_run5537_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_percentageActive_70_percentageBlock_20_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt


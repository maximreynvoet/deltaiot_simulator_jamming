#/usr/bin/bash

# standard = initialize
java -jar deltaiot_simulator.jar 58125 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_58125.txt
# Hybrid jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 58120 -constantjam 30 120 -50 300 265   false false ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run58120_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 58121 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_58121.txt
# Cut jammer - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 58122 -constantjam 30 120 -50 250 350   false false ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run58122_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 58123 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_58123.txt
# Leaf jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 44126 -constantjam 30 120 -50 630 420   false false ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run44126_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt


# mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 59132 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_59132.txt
# Hybrid jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 59133 -constantjam 30 120 -50 300 265   true true ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run59133_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 59134 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_59134.txt
# Cut jammer - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 59135 -constantjam 30 120 -50 250 350   true true ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run59135_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 59136 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_59136.txt
# Leaf jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 44130 -constantjam 30 120 -50 630 420   true true ARIMA > ./../output/deltaiotv1/details/constantjam/details_jam_run44130_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt



#/usr/bin/bash
# standard = initialize
java -jar deltaiot_simulator.jar 5125 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_5125.txt
# Hybrid jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 8120 -reactivejam 30 120 -50 300 265   false false ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run8120_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 8121 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_0121.txt
# Cut jammer - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 8122 -reactivejam 30 120 -50 250 350   false false ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run8122_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 0123 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_0123.txt
# Leaf jammer  - ARIMA - RSSI false and Mitigation false
java -jar deltaiot_simulator.jar 8124 -reactivejam 30 120 -50 630 420   false false ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run8124_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_false_rssiconfirmation_false_mitigationMethod_ARIMA.txt


# mitigation
# standard = initialize
java -jar deltaiot_simulator.jar 9132 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_9132.txt
# Hybrid jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 9133 -reactivejam 30 120 -50 300 265   true true ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run9133_jamX300_jamY265_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 9134 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_9134.txt
# Cut jammer - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 9135 -reactivejam 30 120 -50 250 350   true true ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run9135_jamX250_jamY350_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
# standard = initialize
java -jar deltaiot_simulator.jar 9136 standard ARIMA > ./../output/deltaiotv1/details/standard/standard_9136.txt
# Leaf jammer  - ARIMA - RSSI true and Mitigation true
java -jar deltaiot_simulator.jar 9137 -reactivejam 30 120 -50 630 420   true true ARIMA > ./../output/deltaiotv1/details/reactivejam/details_jam_run9137_jamX630_jamY420_jamStart30_jamStop120_jamPower-50.0_mitigation_true_rssiconfirmation_true_mitigationMethod_ARIMA.txt
